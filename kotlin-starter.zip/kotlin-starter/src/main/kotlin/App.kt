/*
Nama  : Helmy Awal Riyanto
Kelas : XI RPL 5
No    : 13
 */
fun main() {
    println("Hello Kotlin")
}